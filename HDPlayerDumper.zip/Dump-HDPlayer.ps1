# === Dump-HDPlayer.ps1 (portable + fixed) ===

# Get the folder this script is in
$ScriptPath = $MyInvocation.MyCommand.Path
if (-not $ScriptPath) {
    Write-Host "[ERROR] Don't paste! Run this script as a .ps1 file." -ForegroundColor Red
    exit 1
}

# Use relative paths (portable)
$BasePath = Split-Path -Parent $ScriptPath
$ProcDump = Join-Path $BasePath "tools\procdump.exe"
$DumpFolder = Join-Path $BasePath "dumps"

# Create dump folder
if (!(Test-Path $DumpFolder)) {
    New-Item -ItemType Directory -Path $DumpFolder -Force | Out-Null
}

# Check if procdump exists
if (!(Test-Path $ProcDump)) {
    Write-Host "[ERROR] Missing 'tools\procdump.exe'" -ForegroundColor Red
    exit 1
}

# Detect HD-Player process
$proc = Get-Process -Name "HD-Player" -ErrorAction SilentlyContinue
if (-not $proc) {
    Write-Host "[ERROR] HD-Player is not running." -ForegroundColor Red
    exit 1
}

# Build dump file name
$hdPid = $proc.Id
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$dumpFile = Join-Path $DumpFolder "HDPlayer_$timestamp.dmp"

# Dump process memory
Write-Host "[INFO] Dumping HD-Player.exe (PID: $hdPid)..."
Start-Process -FilePath $ProcDump -ArgumentList "-ma $hdPid `"$dumpFile`"" -NoNewWindow -Wait

# Verify
if (Test-Path $dumpFile) {
    Write-Host "[SUCCESS] Dump saved to: $dumpFile" -ForegroundColor Green
} else {
    Write-Host "[FAIL] Dump creation failed." -ForegroundColor Red
}